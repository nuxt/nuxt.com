# eve-raycast

Local prototype of an [Eve](https://eve.dev) extension for Raycast External Agents. Nothing is published to npm.

## Use it

Mount the package in `agent/extensions/raycast.ts`:

```ts
import raycast from 'eve-raycast'
import { raycastAuthAdapter } from '../lib/raycast.js'

export default raycast({
  basePath: '/eve/v1/raycast',
  bot: {
    id: 'nuxi',
    name: 'Nuxi',
    description: 'Your Nuxt companion',
    icon: '/nuxi.png'
  },
  auth: raycastAuthAdapter
})
```

The extension supplies discovery, account metadata, messages, history replay, SSE, cancellation, revocation, Raycast instructions, and cancellation when a turn pauses for approval. It never approves a paused action. Eve retains the conversation; no separate transport database is needed.

The `raycast()` factory types its configuration directly; no separate options declaration or type assertion is needed. All features are enabled by default.

`icon`, `auth.signIn` and `continueUrl` accept absolute URLs or paths relative to the current deployment origin. `continueUrl` defaults to `/`, so previews continue on themselves. Reverse proxies must overwrite `x-forwarded-host` and `x-forwarded-proto` with the original public host and protocol; the extension uses those when present. Set `publicOrigin` explicitly when a local proxy doesn't forward that information (for example, `http://localhost:3000` for a separate Nuxt frontend). This override applies to all three URLs. These URLs are display/navigation links, never authentication destinations for forwarding credentials.

Serve a square icon from the application. `basePath` defaults to `/raycast`; the protocol endpoints are beneath `<basePath>/v1`. The Nuxi path above retains its existing Nuxt/Eve mount.

## Authentication

The application owns login, credential storage, permissions and revocation. Supply:

```ts
import type { RaycastAuth } from 'eve-raycast/channel'

export const auth: RaycastAuth = {
  signIn: '/connect',
  async authenticate(request) {
    const account = await verifyYourCredential(request)
    return {
      user: { id: account.id, name: account.name },
      auth: account.eveIdentity,
      expiresAt: account.expiresAt
    }
  },
  async revoke(request) {
    await revokeYourCredential(request)
  }
}
```

Return an authenticated Eve user identity. Throw `new RaycastHttpError(401)` or `new RaycastHttpError(403)` from `eve-raycast/channel` to reject a request. Unexpected errors produce a sanitized 503 response. Public discovery does not authenticate; conversation routes authenticate before accessing sessions. The supplied Eve identity is passed through unchanged, so the application decides admin access. The extension isolates thread IDs by the returned user ID.

## Features

| Setting | Default | Behavior when disabled |
| --- | --- | --- |
| `enabled` | `true` | Every endpoint returns 404 before authentication/session access |
| `features.toolActivity` | `true` | Replies still replay; tool events are omitted |
| `features.cancellation` | `true` | Cancellation returns 404 and never cancels the session |
| `features.textContext` | `true` | Requests containing text context return 400 |

Files, screen context and endpoint-wide events are unsupported and advertised as disabled. Unknown feature flags fail configuration validation. Configure features before starting a new conversation: changing event projection settings changes replay cursors.

## Local development

Requires Node 24+ and Eve 0.91.0 or newer. This prototype was built against Eve 0.91.0.

```sh
npm install
npm run build
npm run typecheck
npm test
npm link
```

In a consumer with its dependencies installed, run `npm link eve-raycast --no-save --ignore-scripts --package-lock=false` for local development.

For CI and preview deployments, build and pack instead:

```sh
npm run build
npm pack --pack-destination /path/to/consumer/vendor
```

Declare `"eve-raycast": "file:vendor/eve-raycast-0.0.0-prototype.2.tgz"` in the consumer's dependencies and update its lockfile. Commit the archive with the consumer. It contains the compiled extension and declarations, so deployment doesn't depend on this checkout or an npm publication.
Rebuild this package after edits, then restart/rebuild Nuxi. The `eve.extension` source and distribution metadata allow Eve to discover the package contributions. Public `eve-raycast/channel` and `eve-raycast/protocol` exports are useful for tests and applications needing a channel factory directly.

Mounting as `agent/extensions/raycast.ts` gives the channel the Eve name `raycast__raycast`. This differs from Nuxi's former root `raycast` channel: start a fresh chat for the prototype. Old root-channel conversations are not migrated automatically.

